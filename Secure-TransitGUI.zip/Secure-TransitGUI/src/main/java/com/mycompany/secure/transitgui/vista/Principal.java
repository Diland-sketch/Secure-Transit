/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.secure.transitgui.vista;

import com.mycompany.secure.transitgui.entidades.*;

/**
 *
 * @author OSMAR LOPEZ
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
//        Usuario u1 = new Usuario("Diland Andres", "Lopez Florez", 1066867458, 'M', "dilandlopez10@gmail.com", "12345"); 
        
    }
    
}
